package com.cg.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.exception.CustomerdoesnotExist;
import com.cg.capstore.repo.ICustomerProfileChangeRepo;



@Service
@Transactional
public class CustomerProfileChangeService implements ICustomerProfileChangeSercvice{

	@Autowired
	private ICustomerProfileChangeRepo repo;

	@Override
	public Customer changeProfile(Customer customer) throws CustomerdoesnotExist {
		if(customer.getCustomerMobileNo()==null)
			throw new CustomerdoesnotExist("Customer Doest not Exist");
		
		return repo.changeProfile(customer);
	}

	
	}


