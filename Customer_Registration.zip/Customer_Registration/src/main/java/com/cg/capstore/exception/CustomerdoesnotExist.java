package com.cg.capstore.exception;

public class CustomerdoesnotExist extends Exception{

	public CustomerdoesnotExist(String arg0) {
		super(arg0);
	}

}
